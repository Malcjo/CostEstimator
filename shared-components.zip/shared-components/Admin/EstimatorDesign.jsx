export default function EstimatorDesign() {
  return <p>Estimator Design</p>;
}
